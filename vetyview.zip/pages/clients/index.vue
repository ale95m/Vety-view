<template>
  <v-container>
    <v-toolbar flat color="transparent">
      <v-toolbar-title class="hidden-sm-and-down">
        Clientes
      </v-toolbar-title>
      <v-divider
        class="mx-4 hidden-sm-and-down"
        inset
        vertical
      />
      <v-spacer />
      <v-text-field
        v-model="filter"
        append-icon="mdi-magnify"
        label="Buscar clientes"
        single-line
        hide-details
      />
      <v-btn
        color="primary"
        dark
        class="ml-3"
        @click="newItem"
      >
        <v-icon>mdi-account-plus</v-icon>
        <span class="ml-1 hidden-sm-and-down">Cliente</span>
      </v-btn>
    </v-toolbar>
    <v-row>
      <v-col />
    </v-row>
    <v-data-table
      :headers="fields"
      :items="items"
      item-key="id"
      :items-per-page="5"
      class="elevation-1"
    >
      <template v-slot:item.last_visit="{ item }">
        {{ $moment(item.last_visit).format('YYYY-MM-DD') }}
      </template>
      <template v-slot:item.created_at="{ item }">
        {{ $moment(item.created_at).format('YYYY-MM-DD') }}
      </template>
      <template v-slot:item.level="{ item }">
        <v-rating v-model="item.level" dense small readonly color="primary" />
      </template>
      <template v-slot:item.actions="{ item }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-icon
              small
              class="mr-1"
              v-bind="attrs"
              v-on="on"
              @click="editItem(item)"
            >
              mdi-pencil
            </v-icon>
          </template>
          <span>Editar</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-icon
              small
              class="mr-1"
              v-bind="attrs"
              @click="removeItem(item)"
              v-on="on"
            >
              mdi-delete
            </v-icon>
          </template>
          <span>Dar de baja</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-icon
              small
              v-bind="attrs"
              v-on="on"
              @click="removeItem(item)"
            >
              mdi-eye
            </v-icon>
          </template>
          <span>Ver</span>
        </v-tooltip>
      </template>
    </v-data-table>
    <v-dialog
      v-model="modal"
      width="500"
    >
      <v-card>
        <v-card-title
          class="headline grey lighten-2"
          primary-title
        >
          Privacy Policy
        </v-card-title>

        <v-card-text>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        </v-card-text>

        <v-divider />

        <v-card-actions>
          <v-spacer />
          <v-btn
            color="primary"
            text
            @click="dialog = false"
          >
            I accept
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import client from '../../plugins/apis/vety/client'

export default {
  name: 'Index',
  async asyncData ({ $axios }) {
    try {
      const res = await client.getClients($axios)
      return {
        apiData: JSON.parse(res.data.data)
      }
    } catch (errors) {
      console.log(errors)
    }
  },
  data () {
    return {
      modal: false,
      items: [],
      filter: [],
      expanded: [],
      fields: [
        {
          text: 'Nombre',
          align: 'start',
          sortable: true,
          value: 'name'
        },
        { text: 'Mascotas', value: 'pets' },
        { text: 'Visitas', value: 'visits' },
        { text: 'Última visita', value: 'last_visit' },
        { text: 'Fecha de alta', value: 'created_at' },
        { text: 'Deuda', value: 'expense' },
        { text: 'Nivel', value: 'level' },
        { text: 'Opciones', value: 'actions', sortable: false }
      ]
    }
  },
  created () {
    this.items = this.apiData
  },
  methods: {
    async getClients () {
      try {
        this.apiResponse(await client.getClients(this.$axios))
        this.items = this.responseData()
        console.log(this.responseData())
      } catch (errors) {
        console.log(errors)
      }
    },
    newItem () {
      this.modal = !this.modal
    },
    editItem (item) {

    },
    removeItem (item) {

    }
  }
}
</script>

<style scoped>

</style>
