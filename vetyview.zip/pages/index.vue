<template>
  <v-container class="fill-height">
    <v-row
      align="center"
      justify="center"
    >
      <v-col cols="8" sm="4" md="3">
        <v-container>
          <v-img src="/images/system/MyLogo.svg" />
        </v-container>
      </v-col>
      <v-col cols="12" class="text-center text--disabled">
        <p class="headline">
          SISTEMA DE GESTIÓN VETERINARIA
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: 'Index',
  data () {
    return {

    }
  }
}
</script>

<style scoped>

</style>
