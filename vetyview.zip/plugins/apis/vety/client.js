export default {
  async getClients (axios) {
    return await axios.get('/clients')
  }
}
