import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2967b708 = () => interopDefault(import('..\\pages\\calendar\\index.vue' /* webpackChunkName: "pages_calendar_index" */))
const _8d378b74 = () => interopDefault(import('..\\pages\\clients\\index.vue' /* webpackChunkName: "pages_clients_index" */))
const _41d91f75 = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages_auth_login" */))
const _1b6758f4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/calendar",
    component: _2967b708,
    name: "calendar"
  }, {
    path: "/clients",
    component: _8d378b74,
    name: "clients"
  }, {
    path: "/auth/login",
    component: _41d91f75,
    name: "auth-login"
  }, {
    path: "/",
    component: _1b6758f4,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
