<template>
    $END$
</template>

<script>
    export default {
        name: "create"
    }
</script>

<style scoped>

</style>
